# -*- coding: utf-8 -*-
"""
Created on Thu Mar 30 19:14:50 2023

@author: franc
"""

# Importing Libraries
import pandas as pd
import numpy as np
data = pd.read_csv('transaction.csv', sep=';')

# Data Summary
data.info()

# Working with calculations


CostPerItem = data['CostPerItem']
NumberOfItemsPurchased = data['NumberOfItemsPurchased']
data['CostPerTransaction'] = CostPerItem * NumberOfItemsPurchased

# Column Calculations
data['SalesPerTransaction'] = data['SellingPricePerItem'] * data['NumberOfItemsPurchased']
data['ProfitPerTransaction'] = data['SalesPerTransaction'] - data['CostPerTransaction']
data['MarkUp'] = (data['ProfitPerTransaction'])/data['CostPerTransaction']
data['MarkUp'] = round(data['MarkUp'], 2)

# Modifying Dates/Combining data fields
# Changing data type
day = data['Day'].astype(str)
year = data['Year'].astype(str)
data['Date'] = day+'-'+data['Month']+'-'+year

# Using iloc to view specific columns/rows

# Using split to split client keywords
Split_col = data['ClientKeywords'].str.split(',', expand=True)

# Creating columns for split columns in our dataframe
data['ClientAge'] = Split_col[0]
data['ClientType'] = Split_col[1]
data['LengthOfContract'] = Split_col[2]

# Using replace function
data['ClientAge'] = data['ClientAge'].str.replace('[', '')
data['LengthOfContract'] = data['LengthOfContract'].str.replace(']', '')

# Using lower case for item description
data['ItemDescription'] = data['ItemDescription'].str.lower()

# Merging 2 files
Seasons = pd.read_csv('value_inc_seasons.csv', sep = ';')
data_merged = pd.merge(data, Seasons, on = 'Month')

# Dropping Columns
data_merged = data_merged.drop('ClientKeywords', axis =1)
data_merged = data_merged.drop('Day', axis =1)
data_merged = data_merged.drop(['Year', 'Month'], axis =1)

# Export our cleaned file to csv
data_merged.to_csv('ValueInc_Cleaned2.csv', index = False)